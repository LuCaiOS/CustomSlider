//
//  ViewController.m
//  LCSSegmentSliderDemo
//
//  Created by 逯常松 on 16/6/23.
//  Copyright © 2016年 逯常松. All rights reserved.
//

#import "ViewController.h"
#import "LCSCustomSegmentSlider.h"


@interface ViewController ()

@property (nonatomic, weak) UILabel *sliderValueLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIImage *sliderImage = [UIImage imageNamed:@"window_detail_slider_max"];
    
    LCSCustomSegmentSlider *windowSlider = [[LCSCustomSegmentSlider alloc] init];
    
    windowSlider.frame = CGRectMake(50, 135, sliderImage.size.width, sliderImage.size.height);
    
    //一定记得添加上图片
    [windowSlider setThumbImage:[UIImage imageNamed:@"window_detail_slider_thumb"] forState:UIControlStateNormal];
    [windowSlider setMinimumTrackImage:[UIImage imageNamed:@"window_detail_slider_max"] forState:UIControlStateNormal];
    [windowSlider setMaximumTrackImage:[UIImage imageNamed:@"window_detail_slider_min"] forState:UIControlStateNormal];
    
    //765 × 100 pixels
//    windowSlider.continuous = NO;
    
    [self.view addSubview:windowSlider];
    
    [windowSlider addTarget:self action:@selector(windowSliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    
    UILabel *sliderValueLabel = [[UILabel alloc] init];
    sliderValueLabel.frame = CGRectMake(windowSlider.frame.origin.x, windowSlider.frame.origin.y+windowSlider.frame.size.height*2, windowSlider.frame.size.width, 40);
    _sliderValueLabel = sliderValueLabel;
    sliderValueLabel.font = [UIFont boldSystemFontOfSize:20];
    sliderValueLabel.textColor = [UIColor blackColor];
    _sliderValueLabel.text = [NSString stringWithFormat:@"滑动条值为:%.2f",windowSlider.value];
    
    [self.view addSubview:sliderValueLabel];
    

    // Do any additional setup after loading the view, typically from a nib.
}

- (void)windowSliderValueChanged:(UISlider *)slider
{
    
    _sliderValueLabel.text = [NSString stringWithFormat:@"滑动条值为:%.2f",slider.value];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
