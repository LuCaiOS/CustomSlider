//
//  UIImage+LCSExtension.h
//  Purchase
//
//  Created by 逯常松 on 15/8/11.
//  Copyright (c) 2015年 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LCSExtension)

/**
 *  拉伸图片
 *
 *  @param scale 拉伸的位置比.默认x,y都是scale*x,scale*y。中间位置(1*1拉伸)
 *
 *  @return 拉伸后的图片
 */

- (UIImage *)strechImageWithScale:(CGFloat)scale;
/**
 *  拉伸图片.默认x,y都是0.5。中间位置(1*1拉伸)
 *
 *  @return 拉伸后的图片
 */

- (UIImage *)strechImage;

- (UIImage *)scaleToSize:(CGSize)size;

- (UIImage *)imageWithTintColor:(UIColor *)tintColor;

- (UIImage *)imageWithGradientTintColor:(UIColor *)tintColor;

- (UIImage *)imageWithTintColor:(UIColor *)tintColor blendMode:(CGBlendMode)blendMode;

//截屏
- (UIImage *)imageFromView:(UIView *)view;

//方形变圆形
+ (instancetype)circleImageWithName:(NSString *)name borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor;


- (UIImage *)clicpImageWithRect:(CGRect)rect;

@end
