//
//  LCSCustomSlider.h
//  CustomSlider
//
//  Created by 逯常松 on 16/6/7.
//  Copyright © 2016年 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LCSCustomSegmentSlider : UIControl

@property (nullable,nonatomic, weak)  UIImageView       *thumImageView;

@property(nonatomic) float value;                                 // default 0.0. this value will be pinned to min/max
@property(nonatomic) float minimumValue;                          // default 0.0. the current value may change if outside new min value
@property(nonatomic) float maximumValue;                          // default 1.0. the current value may change if outside new max value

@property(nullable, nonatomic,strong) UIImage *minimumValueImage;          // default is nil. image that appears to left of control (e.g. speaker off)
@property(nullable, nonatomic,strong) UIImage *maximumValueImage;          // default is nil. image that appears to right of control (e.g. speaker max)

@property(nonatomic,getter=isContinuous) BOOL continuous;        // if set, value change events are generated any time the value changes due to dragging. default = YES


@property(nullable,nonatomic,retain) UIColor *minimumTrackTintColor;
@property(nullable,nonatomic,retain) UIColor *maximumTrackTintColor;
@property(nullable,nonatomic,retain) UIColor *thumbTintColor;

- (void)setValue:(float)value animated:(BOOL)animated; // move slider at fixed velocity (i.e. duration depends on distance). does not send action

- (void)setMinimumTrackImage:(nullable UIImage *)image forState:(UIControlState)state;
- (void)setMaximumTrackImage:(nullable UIImage *)image forState:(UIControlState)state;
- (void)setThumbImage:(nullable UIImage *)image forState:(UIControlState)state;

// lets a subclass lay out the track and thumb as needed
- (CGRect)minimumValueImageRectForBounds:(CGRect)bounds;
- (CGRect)maximumValueImageRectForBounds:(CGRect)bounds;
- (CGRect)trackRectForBounds:(CGRect)bounds;
- (CGRect)thumbRectForBounds:(CGRect)bounds trackRect:(CGRect)rect value:(float)value;

@end
