//
//  AppDelegate.h
//  LCSSegmentSliderDemo
//
//  Created by 逯常松 on 16/6/23.
//  Copyright © 2016年 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

